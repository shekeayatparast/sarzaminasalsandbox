// Helper functions for سرزمین عسل

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

// Convert english digits to Persian
export function toPersianDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

// Format number with thousands separator (Persian style)
export function formatNumber(n: number): string {
  return toPersianDigits(n.toLocaleString("en-US"));
}

// Format as Toman currency
export function formatToman(n: number): string {
  return `${formatNumber(n)} تومان`;
}

// Format as Rial currency
export function formatRial(n: number): string {
  return `${formatNumber(n * 10)} ریال`;
}

// Generate a unique extra amount between 1 and UNIQUE_AMOUNT_MAX (999)
// for tracking each order in bank statement
export function generateUniqueAmount(): number {
  return Math.floor(Math.random() * 999) + 1;
}

// Generate a human-readable order number like HN-10245
export function generateOrderNumber(): string {
  const num = Math.floor(10000 + Math.random() * 89999);
  return `HN-${num}`;
}

// Calculate price for a container of honey
export function containerPrice(pricePerKg: number, sizeKg: number): number {
  return Math.round(pricePerKg * sizeKg);
}

// Order status labels (Persian)
export const ORDER_STATUS_LABELS: Record<string, string> = {
  awaiting_payment: "در انتظار پرداخت",
  paid: "پرداخت ثبت شد",
  confirmed: "تأیید مدیریت",
  preparing: "در حال آماده‌سازی",
  shipped: "تحویل به پست",
  delivered: "تحویل داده شد",
  cancelled: "لغو شد",
};

// Order status → step index (for progress display)
export const ORDER_STATUS_STEPS = [
  "awaiting_payment",
  "paid",
  "confirmed",
  "preparing",
  "shipped",
  "delivered",
] as const;

export function statusStepIndex(status: string): number {
  const idx = ORDER_STATUS_STEPS.indexOf(status as any);
  return idx >= 0 ? idx : -1; // -1 = cancelled or unknown
}

// ── Date / time (Iran timezone + Jalali calendar) ────────────────────
// The site may be viewed from any timezone, but ALL dates must be shown
// in Iran Standard Time (Asia/Tehran, UTC+03:30, no DST since 2022)
// using the Persian (Jalali / Shamsi) calendar — never the viewer's
// local time, never the Gregorian calendar.
export const IRAN_TZ = "Asia/Tehran";

/** Format a Date as a Persian (Jalali) date-time string in Iran time. */
export function formatJalaliDateTime(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  try {
    return new Intl.DateTimeFormat("fa-IR", {
      timeZone: IRAN_TZ,
      calendar: "persian",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(date);
  } catch {
    return date.toLocaleString("fa-IR", { timeZone: IRAN_TZ });
  }
}

/** Format a Date as a Persian (Jalali) date only (no time) in Iran time. */
export function formatJalaliDate(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  try {
    return new Intl.DateTimeFormat("fa-IR", {
      timeZone: IRAN_TZ,
      calendar: "persian",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date);
  } catch {
    return date.toLocaleDateString("fa-IR", { timeZone: IRAN_TZ });
  }
}

/** Format a Date as Persian time-only (HH:MM:SS) in Iran time. */
export function formatJalaliTime(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  try {
    return new Intl.DateTimeFormat("fa-IR", {
      timeZone: IRAN_TZ,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).format(date);
  } catch {
    return date.toLocaleTimeString("fa-IR", { timeZone: IRAN_TZ });
  }
}

/** Returns the current Jalali (Shamsi) year as a Persian-digit string, e.g. "۱۴۰۳". */
export function currentJalaliYear(): string {
  return new Intl.DateTimeFormat("fa-IR", {
    timeZone: IRAN_TZ,
    calendar: "persian",
    year: "numeric",
  }).format(new Date());
}

// ── Iranian mobile phone helpers (client-safe) ────────────────────────
// These are used by both server (auth.ts) and client (register/login pages)
// so they must NOT import any server-only modules (next/headers, db, etc.).

const FA_DIGITS_ARR = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
const AR_DIGITS_ARR = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];

/** Convert Persian (۰-۹) and Arabic-Indic (٠-٩) digits to ASCII 0-9. */
export function persianToEnglishDigits(s: string): string {
  let out = s;
  for (let i = 0; i < 10; i++) {
    out = out.replace(new RegExp(FA_DIGITS_ARR[i], "g"), String(i));
    out = out.replace(new RegExp(AR_DIGITS_ARR[i], "g"), String(i));
  }
  return out;
}

/**
 * Normalize an Iranian mobile number to the canonical `09123456789` form.
 * Accepts Persian/Arabic digits, spaces, dashes, parentheses, and the
 * country code (+98 / 0098). Returns the raw string (stripped of non-digits)
 * if it doesn't match any known prefix.
 */
export function normalizeIranPhone(phone: string): string {
  const normalized = persianToEnglishDigits(
    phone.replace(/[\s\-()]/g, "")
  );
  if (normalized.startsWith("+98")) return "0" + normalized.slice(3);
  if (normalized.startsWith("0098")) return "0" + normalized.slice(4);
  return normalized;
}

/**
 * Validate an Iranian mobile number. Accepts:
 *  - 09123456789      (11 digits starting with 09)
 *  - +989123456789    (country code + 10 digits)
 *  - 00989123456789   (double-zero country code)
 * Both Persian and Arabic-Indic digits are accepted.
 */
export function isValidIranPhone(phone: string): boolean {
  const normalized = persianToEnglishDigits(
    phone.replace(/[\s\-()]/g, "")
  );
  if (/^09\d{9}$/.test(normalized)) return true;
  if (/^\+989\d{9}$/.test(normalized)) return true;
  if (/^00989\d{9}$/.test(normalized)) return true;
  return false;
}

// ── Password strength validation (client-safe) ────────────────────────
// Pure function — no server-only deps. Lives here so client components
// (register/login/profile forms) can import it without pulling in
// next/headers or the db client.
export function isStrongPassword(pwd: string): { ok: boolean; reason?: string } {
  if (pwd.length < 6) return { ok: false, reason: "رمز عبور باید حداقل ۶ کاراکتر باشد" };
  if (!/\d/.test(pwd)) return { ok: false, reason: "رمز عبور باید حداقل یک عدد داشته باشد" };
  if (!/[a-zA-Z]/.test(pwd)) return { ok: false, reason: "رمز عبور باید حداقل یک حرف داشته باشد" };
  return { ok: true };
}
